package com.guirec;
/** Implemented by ChatScreenMixin to read/write the text typed in the chat box. */
public interface ChatAccess { String guirec$getText(); void guirec$setText(String s); }
