package com.guirec;
/** Implemented by CreativeScreenMixin: lets us read/set the creative inventory tab, scroll and search text. */
public interface CreativeAccess {
    int guirec$getTab(); void guirec$setTab(int i);
    float guirec$getScroll(); void guirec$setScroll(float f);
    String guirec$getSearch(); void guirec$setSearch(String s);
}
