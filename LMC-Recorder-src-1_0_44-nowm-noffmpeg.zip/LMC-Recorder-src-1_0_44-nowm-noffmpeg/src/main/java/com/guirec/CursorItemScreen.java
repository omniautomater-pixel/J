package com.guirec;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * v1.0.33: search EVERY item (or block) picture of the game and use it as your replay cursor.
 * The pictures are read from the running game's resources (textures/item and textures/block, so a resource pack changes them too).
 * Type in the search box (words of the name, e.g. "diamond pick"), tap a picture to select it (its name is shown), tap it again or press
 * "Use" to load it into the cursor editor, where you can still change it and save it under a name.
 */
public class CursorItemScreen extends Screen {
    private static boolean blocks;            // false = items, true = blocks (kept while the game runs)
    private static String query = "";

    private final CursorEditorScreen editor;
    private final List<String> names = new ArrayList<>();                 // file names without .png, sorted
    private final Map<String, Resource> res = new HashMap<>();
    private final List<String> shown = new ArrayList<>();                 // names that match the search
    private final Map<String, int[]> pxCache = new HashMap<>();
    private final Map<String, int[][]> runCache = new HashMap<>();
    private int page, sel = -1;
    private int cols = 1, rows = 1, cell = 20, scale = 1, gx = 8, gy = 40, per = 1;
    private EditBox box;
    private String note = "";

    public CursorItemScreen(CursorEditorScreen editor) {
        super(Component.literal("Cursor items"));
        this.editor = editor;
        listAll();
        filter();
    }

    private void listAll() {
        names.clear(); res.clear();
        try {
            final String dir = blocks ? "textures/block" : "textures/item";
            final int pre = dir.length() + 1;
            Map<Identifier, Resource> m = net.minecraft.client.Minecraft.getInstance().getResourceManager().listResources(dir, id -> {
                String p = id.getPath(); return p.endsWith(".png") && p.indexOf('/', pre) < 0;
            });
            TreeMap<String, Resource> sorted = new TreeMap<>();
            for (var e : m.entrySet()) {
                String p = e.getKey().getPath();
                sorted.putIfAbsent(p.substring(pre, p.length() - 4), e.getValue());
            }
            names.addAll(sorted.keySet());
            res.putAll(sorted);
        } catch (Throwable t) { note = "Could not list the pictures"; }
    }

    private void filter() {
        shown.clear();
        String[] tok = query.toLowerCase(Locale.ROOT).trim().split("[ _]+");
        for (String n : names) {
            String h = n.replace('_', ' ');
            boolean ok = true;
            for (String t : tok) if (!t.isEmpty() && !h.contains(t)) { ok = false; break; }
            if (ok) shown.add(n);
        }
        page = 0; sel = -1;
    }

    private static String pretty(String n) {
        StringBuilder sb = new StringBuilder();
        for (String w : n.split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    private int[] pixels(String n) {
        int[] px = pxCache.get(n);
        if (px != null) return px;
        px = new int[CursorStyle.N * CursorStyle.N];
        try {
            Resource r = res.get(n);
            if (r != null) try (InputStream in = r.open()) { px = CursorStyle.readPixels(in); }
        } catch (Throwable ignored) {}
        pxCache.put(n, px);
        return px;
    }

    private int[][] runs(String n) {
        int[][] rs = runCache.get(n);
        if (rs != null) return rs;
        int N = CursorStyle.N;
        int[] px = pixels(n);
        List<int[]> out = new ArrayList<>();
        for (int r = 0; r < N; r++) {
            int c = 0;
            while (c < N) {
                int col = px[r * N + c];
                if ((col >>> 24) == 0) { c++; continue; }
                int e = c + 1;
                while (e < N && px[r * N + e] == col) e++;
                out.add(new int[] { c, r, e - c, col });
                c = e;
            }
        }
        rs = out.toArray(new int[0][]);
        runCache.put(n, rs);
        return rs;
    }

    private int pages() { return Math.max(1, (shown.size() + per - 1) / per); }

    @Override
    protected void init() {
        int bh = 18;
        scale = (this.height >= 230 && this.width >= 320) ? 2 : 1;
        cell = 16 * scale + 4;
        int y2 = this.height - 22;
        gx = 8; gy = 40;
        cols = Math.max(1, (this.width - 16) / cell);
        rows = Math.max(1, (y2 - 16 - gy) / cell);
        per = cols * rows;
        page = Math.max(0, Math.min(page, pages() - 1));

        int tw = 84;
        box = new EditBox(this.font, 8, 18, Math.max(60, this.width - 16 - tw - 4), 18, Component.literal("Search"));
        box.setMaxLength(40);
        box.setHint(Component.literal("Search: diamond sword, apple, torch..."));
        box.setValue(query);
        box.setResponder(t -> { query = t; filter(); });
        addRenderableWidget(box);
        addRenderableWidget(Button.builder(Component.literal(blocks ? "Blocks" : "Items"), b -> {
            blocks = !blocks; listAll(); filter(); rebuildWidgets();
        }).bounds(this.width - 8 - tw, 18, tw, 18).build());

        addRenderableWidget(Button.builder(Component.literal("<"), b -> page = Math.max(0, page - 1)).bounds(8, y2, 30, bh).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> page = Math.min(pages() - 1, page + 1)).bounds(42, y2, 30, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(this.width - 8 - 50, y2, 50, bh).build());
        addRenderableWidget(Button.builder(Component.literal("Use"), b -> useSelected()).bounds(this.width - 8 - 50 - 4 - 50, y2, 50, bh).build());
    }

    private void useSelected() {
        if (sel < 0 || sel >= shown.size()) { note = "Tap a picture first"; return; }
        String n = shown.get(sel);
        int[] px = pixels(n);
        int[] tip = CursorStyle.tipOf(px);
        editor.takeItem(px.clone(), tip[0], tip[1], pretty(n));
        this.minecraft.gui.setScreen(editor);
    }

    private int indexAt(double x, double y) {
        int c = (int) Math.floor((x - gx) / cell), r = (int) Math.floor((y - gy) / cell);
        if (c < 0 || r < 0 || c >= cols || r >= rows) return -1;
        int i = page * per + r * cols + c;
        return i < shown.size() ? i : -1;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        if (ev.button() == InputConstants.MOUSE_BUTTON_LEFT) {
            int i = indexAt(ev.x(), ev.y());
            if (i >= 0) {
                this.setFocused(null);
                if (i == sel) useSelected(); else { sel = i; note = ""; }
                return true;
            }
        }
        return super.mouseClicked(ev, dbl);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        if (sy != 0) { page = Math.max(0, Math.min(pages() - 1, page + (sy < 0 ? 1 : -1))); return true; }
        return super.mouseScrolled(x, y, sx, sy);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);
        g.text(this.font, "Pick any Minecraft " + (blocks ? "block" : "item") + " as your cursor   (" + shown.size() + " found)", 8, 5, 0xFFFFFFFF);
        int hover = indexAt(mx, my);
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
            int i = page * per + r * cols + c;
            if (i >= shown.size()) break;
            int x = gx + c * cell, y = gy + r * cell;
            g.fill(x, y, x + cell - 1, y + cell - 1, i == sel ? 0xFF5A5A20 : (i == hover ? 0xFF3A3A44 : 0xFF26262C));
            if (i == sel) {
                g.fill(x, y, x + cell - 1, y + 1, 0xFFFFFF55); g.fill(x, y + cell - 2, x + cell - 1, y + cell - 1, 0xFFFFFF55);
                g.fill(x, y, x + 1, y + cell - 1, 0xFFFFFF55); g.fill(x + cell - 2, y, x + cell - 1, y + cell - 1, 0xFFFFFF55);
            }
            int ix = x + 2, iy = y + 2;
            for (int[] q : runs(shown.get(i))) g.fill(ix + q[0] * scale, iy + q[1] * scale, ix + (q[0] + q[2]) * scale, iy + (q[1] + 1) * scale, q[3]);
        }
        if (shown.isEmpty()) g.text(this.font, "Nothing found for \"" + query + "\"", gx, gy + 4, 0xFFFFAAAA);
        int y2 = this.height - 22;
        String info;
        int shownIdx = hover >= 0 ? hover : sel;
        if (!note.isEmpty()) info = note;
        else if (shownIdx >= 0 && shownIdx < shown.size()) info = pretty(shown.get(shownIdx)) + "  (" + shown.get(shownIdx) + ")" + (shownIdx == sel ? "  - tap again or press Use" : "");
        else info = "Tap a picture to select it";
        g.text(this.font, info, 8, y2 - 12, 0xFFFFDD66);
        g.text(this.font, (page + 1) + " / " + pages(), 78, y2 + 5, 0xFFCCCCCC);
    }

    @Override
    public void onClose() { this.minecraft.gui.setScreen(editor); }

    @Override
    public boolean isPauseScreen() { return false; }
}
