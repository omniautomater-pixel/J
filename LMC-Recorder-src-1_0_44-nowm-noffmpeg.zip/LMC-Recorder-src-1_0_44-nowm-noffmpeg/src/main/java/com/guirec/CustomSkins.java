package com.guirec;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/**
 * Client-side skin / cape choice for YOUR player (in the game and in replays).
 *  - Folder .minecraft/guirec/skins (made when the game starts): put 64x64 .png skins there.
 *  - "Account skin" (default) = nothing is changed: a premium account shows its real skin, exactly like vanilla.
 *  - A chosen .png replaces the skin of your own player. Other players on a server do NOT see it (it is only on your screen / in your replays).
 *  - Model: Auto (a file name that contains "slim" or "alex" = slim arms, else classic) / Classic / Slim.
 *  - Cape ON = the account's cape if it has one (vanilla); OFF = no cape.
 * Settings are kept in .minecraft/guirec/skin.properties.
 */
public final class CustomSkins {
    private CustomSkins() {}

    public static volatile String selected = "";      // file name inside the skins folder, "" = account skin
    public static volatile int model = 0;             // 0 auto, 1 classic, 2 slim
    public static volatile boolean cape = true;
    public static volatile String error = "";

    private record Loaded(Identifier id, long mtime) {}
    private static final Map<String, Loaded> loaded = new HashMap<>();
    private static final java.util.Set<String> failed = new java.util.HashSet<>();
    private static final Map<String, Long> lastCheck = new HashMap<>();   // the file is looked at once per second, not on every frame

    public static Path dir() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("skins"); }
    private static Path cfg() { return Minecraft.getInstance().gameDirectory.toPath().resolve("guirec").resolve("skin.properties"); }

    /** Game start: make the skins folder (+ a short README inside it) and read the saved choice. */
    public static void init() {
        try {
            Path d = dir();
            Files.createDirectories(d);
            Path readme = d.resolve("README.txt");
            if (!Files.exists(readme)) Files.writeString(readme,
                    "LMC Recorder - custom skins\n\n"
                  + "Put skin files here (.png, 64x64). In the game: Title screen / Pause menu -> Skins -> pick one.\n"
                  + "Name a file e.g. alex_slim.png (contains \"slim\" or \"alex\") for the thin-arm model, or choose the model in the Skins menu.\n"
                  + "Premium account: leave it on \"Account skin\" to keep your real skin. The custom skin is only on YOUR screen and in your replays.\n");
        } catch (Throwable ignored) {}
        try {
            Path p = cfg();
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (InputStream i = Files.newInputStream(p)) { pr.load(i); }
                selected = pr.getProperty("skin", "").trim();
                model = Math.max(0, Math.min(2, Integer.parseInt(pr.getProperty("model", "0").trim())));
                cape = Boolean.parseBoolean(pr.getProperty("cape", "true"));
            }
        } catch (Throwable ignored) {}
    }

    public static void save() {
        try {
            Path p = cfg();
            Files.createDirectories(p.getParent());
            Properties pr = new Properties();
            pr.setProperty("skin", selected);
            pr.setProperty("model", String.valueOf(model));
            pr.setProperty("cape", String.valueOf(cape));
            try (var o = Files.newOutputStream(p)) { pr.store(o, "LMC Recorder skins"); }
        } catch (Throwable ignored) {}
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (var s = Files.list(dir())) {
            s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
             .map(p -> p.getFileName().toString()).sorted(String.CASE_INSENSITIVE_ORDER).forEach(out::add);
        } catch (Throwable ignored) {}
        return out;
    }

    public static void select(String file) { selected = file == null ? "" : file; error = ""; failed.remove(selected); save(); }
    public static void cycleModel() { model = (model + 1) % 3; save(); }
    public static void toggleCape() { cape = !cape; save(); }
    public static void forgetCache() { failed.clear(); error = ""; }

    private static boolean slim(String file) {
        if (model == 1) return false;
        if (model == 2) return true;
        String n = file.toLowerCase(Locale.ROOT);
        return n.contains("slim") || n.contains("alex");
    }

    /** The texture of the chosen file (loaded on first use / when the file changed), or null. Render thread only. */
    private static Identifier texture(String file) {
        try {
            long now = System.currentTimeMillis();
            Loaded cached = loaded.get(file);
            Long lc = lastCheck.get(file);
            if (cached != null && lc != null && now - lc < 1000) return cached.id();
            lastCheck.put(file, now);
            Path p = dir().resolve(file);
            if (!Files.isRegularFile(p)) { error = file + ": file not found"; return null; }
            long mt = Files.getLastModifiedTime(p).toMillis();
            Loaded l = loaded.get(file);
            if (l != null && l.mtime() == mt) return l.id();
            String key = file + "@" + mt;
            if (failed.contains(key)) return null;
            Minecraft mc = Minecraft.getInstance();
            NativeImage img;
            try (InputStream in = Files.newInputStream(p)) { img = NativeImage.read(in); }
            if (img.getWidth() != 64 || img.getHeight() != 64) {
                error = file + ": skin must be 64x64 pixels (this one is " + img.getWidth() + "x" + img.getHeight() + ")";
                img.close(); failed.add(key); return null;
            }
            String safe = file.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]", "_");
            Identifier id = Identifier.parse("guirec:skins/" + safe + "_" + Long.toHexString(mt));
            if (l != null) { try { mc.getTextureManager().release(l.id()); } catch (Throwable ignored) {} }
            final String label = "LMC skin " + file;
            mc.getTextureManager().register(id, new DynamicTexture(() -> label, img));
            loaded.put(file, new Loaded(id, mt));
            error = "";
            return id;
        } catch (Throwable t) {
            error = file + ": " + t.getClass().getSimpleName();
            failed.add(file + "@0");
            return null;
        }
    }

    /** Called for YOUR player's skin (AbstractClientPlayerMixin). Returns the original when nothing has to change. */
    public static PlayerSkin apply(PlayerSkin orig) {
        try {
            if (orig == null) return null;
            Minecraft mc = Minecraft.getInstance();
            if (!mc.isSameThread()) return orig;
            boolean custom = !selected.isEmpty();
            if (!custom && cape) return orig;
            ClientAsset.Texture body = orig.body();
            PlayerModelType type = orig.model();
            boolean secure = orig.secure();
            if (custom) {
                Identifier id = texture(selected);
                if (id != null) { body = new ClientAsset.ResourceTexture(id, id); type = slim(selected) ? PlayerModelType.SLIM : PlayerModelType.WIDE; secure = true; }
                else if (cape) return orig;
            }
            return new PlayerSkin(body, cape ? orig.cape() : null, orig.elytra(), type, secure);
        } catch (Throwable t) {
            return orig;
        }
    }
}
