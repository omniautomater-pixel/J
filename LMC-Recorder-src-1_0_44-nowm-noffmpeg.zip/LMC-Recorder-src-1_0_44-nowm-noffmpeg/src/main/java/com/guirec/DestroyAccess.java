package com.guirec;
import net.minecraft.core.BlockPos;
/** Implemented by GameModeMixin: which block the local player is currently breaking. */
public interface DestroyAccess { BlockPos guirec$destroyPos(); }
