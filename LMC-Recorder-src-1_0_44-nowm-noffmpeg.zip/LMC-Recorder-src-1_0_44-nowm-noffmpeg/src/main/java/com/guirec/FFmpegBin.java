package com.guirec;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Finds an ffmpeg to encode the exported video. This build has NO ffmpeg inside. It uses, in this order:
 *   1) the path written in  .minecraft/guirec/ffmpeg_path.txt  (a file, or a folder that contains ffmpeg)
 *   2) "ffmpeg" from PATH (PC: install ffmpeg and put it in PATH)
 *   3) ffmpeg / libffmpeg.so found in the folders of PATH, LD_LIBRARY_PATH, java.library.path and in env variables with "ffmpeg" in their name
 *      (this is how the launcher's FFmpeg plugin APK shows up on a phone)
 *   4) an installed FFmpeg plugin app under /data/app (Android)
 *   5) usual PC places (/usr/bin, Homebrew, C:\ffmpeg\bin)
 *   6) the ffmpeg of the add-on mod "LMC Recorder FFmpeg" (guirec_ffmpeg, Android arm64): put that mod next to this one and nothing else is needed
 *
 * Android 10+ may refuse to execve() a file from an app data folder, so for every .so also a start through /system/bin/linker64 is tried.
 * The first candidate that answers "ffmpeg -version" is used.
 */
public final class FFmpegBin {
    private static final String RES = "guirec_ffmpeg/arm64-v8a/";
    private static final String[] FILES = {"libc++_shared.so", "libavutil.so", "libswresample.so", "libswscale.so",
            "libavcodec.so", "libavformat.so", "libavfilter.so", "libavdevice.so", "libffmpeg.so"};

    private static List<String> prefix;       // command that starts ffmpeg (without arguments)
    private static String libDir;             // folder for LD_LIBRARY_PATH (Android .so build) or null
    private static boolean x264;
    private static String error = "";
    private static final StringBuilder log = new StringBuilder();

    private record Cand(List<String> cmd, String ld) {}

    private FFmpegBin() {}

    public static String error() { return error; }
    public static String log() { return log.toString(); }
    public static boolean hasX264() { return x264; }
    public static String libDir() { return libDir; }

    public static boolean isAndroid() {
        return new File("/system/bin/linker64").exists() || new File("/system/bin/linker").exists();
    }

    private static String linker() { return new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker"; }

    /** Command prefix to start ffmpeg, or null (see error()). */
    public static synchronized List<String> command(Path gameDir) {
        if (prefix != null) return new ArrayList<>(prefix);
        log.setLength(0); error = "";
        try {
            List<Cand> cands = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            // 1) your own path
            try {
                Path ov = gameDir.resolve("guirec").resolve("ffmpeg_path.txt");
                if (Files.exists(ov)) {
                    for (String line : Files.readAllLines(ov)) {
                        line = line.trim();
                        if (line.isEmpty() || line.startsWith("#")) continue;
                        Path p = Paths.get(line.replace("\"", ""));
                        if (Files.isDirectory(p)) scanDir(cands, seen, p.toString()); else addFile(cands, seen, p);
                        log.append("ffmpeg_path.txt: ").append(line).append('\n');
                        break;
                    }
                }
            } catch (Throwable t) { log.append("ffmpeg_path.txt: ").append(t).append('\n'); }
            // 2) PATH
            cands.add(new Cand(List.of("ffmpeg"), null));
            // 3) folders from the environment
            for (String v : new String[]{"PATH", "LD_LIBRARY_PATH"}) {
                String val = System.getenv(v);
                if (val != null) for (String d : val.split(File.pathSeparator)) scanDir(cands, seen, d);
            }
            String jl = System.getProperty("java.library.path");
            if (jl != null) for (String d : jl.split(File.pathSeparator)) scanDir(cands, seen, d);
            try {
                for (var e : System.getenv().entrySet()) {
                    if (!e.getKey().toLowerCase(Locale.ROOT).contains("ffmpeg") || e.getValue() == null) continue;
                    Path p = Paths.get(e.getValue());
                    if (Files.isDirectory(p)) scanDir(cands, seen, p.toString()); else addFile(cands, seen, p);
                }
            } catch (Throwable ignored) {}
            // 4) FFmpeg plugin app on Android
            if (isAndroid()) androidScan(cands, seen);
            // 5) usual PC places
            for (String s : new String[]{"/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/opt/homebrew/bin/ffmpeg", "/snap/bin/ffmpeg",
                    "C:\\ffmpeg\\bin\\ffmpeg.exe", "C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe"}) {
                try { addFile(cands, seen, Paths.get(s)); } catch (Throwable ignored) {}
            }
            for (Cand c : cands) {
                if (probe(c.cmd(), c.ld())) { prefix = c.cmd(); libDir = c.ld(); return new ArrayList<>(prefix); }
                error = "";
            }
            // 6) the add-on mod "LMC Recorder FFmpeg" (Android arm64)
            if (isAndroid() && FFmpegBin.class.getClassLoader().getResource(RES + "libffmpeg.so") != null) {
                String arch = System.getProperty("os.arch", "");
                boolean arm64 = arch.contains("aarch64") || arch.contains("arm64");
                if (!arm64) error = "this phone is not arm64 (" + arch + "); the ffmpeg add-on mod is arm64 only";
                else {
                    List<Path> dirs = new ArrayList<>();
                    String tmp = System.getProperty("java.io.tmpdir");
                    if (tmp != null) dirs.add(Paths.get(tmp, "guirec-ffmpeg"));
                    dirs.add(gameDir.resolve("guirec").resolve("ffmpeg"));
                    for (Path d : dirs) {
                        try {
                            extract(d);
                            String bin = d.resolve("libffmpeg.so").toString();
                            for (List<String> cand : List.of(List.of(bin), List.of(linker(), bin))) {
                                if (probe(cand, d.toString())) { prefix = cand; libDir = d.toString(); return new ArrayList<>(prefix); }
                            }
                        } catch (Throwable t) { log.append("dir ").append(d).append(": ").append(t).append('\n'); }
                    }
                    if (error.isEmpty()) error = "the ffmpeg add-on did not start on this device (see guirec/export_debug.log)";
                }
            }
            if (error.isEmpty()) error = "ffmpeg not found: install ffmpeg (PC: put it in PATH; phone: the FFmpeg plugin app) or put the \"LMC Recorder FFmpeg\" add-on mod in the mods folder. You can also write the path of ffmpeg into .minecraft/guirec/ffmpeg_path.txt";
        } catch (Throwable t) { error = String.valueOf(t); log.append(t).append('\n'); }
        return null;
    }

    /** ffmpeg / libffmpeg.so inside a folder. */
    private static void scanDir(List<Cand> out, Set<String> seen, String dir) {
        if (dir == null || dir.isBlank()) return;
        try {
            Path d = Paths.get(dir);
            for (String nm : new String[]{"ffmpeg", "ffmpeg.exe", "libffmpeg.so"}) addFile(out, seen, d.resolve(nm));
        } catch (Throwable ignored) {}
    }

    private static void addFile(List<Cand> out, Set<String> seen, Path f) {
        try {
            if (!Files.isRegularFile(f)) return;
            String key = f.toAbsolutePath().toString();
            if (!seen.add(key)) return;
            String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
            if (n.endsWith(".so")) {
                String d = f.toAbsolutePath().getParent().toString();
                out.add(new Cand(List.of(key), d));
                if (isAndroid()) out.add(new Cand(List.of(linker(), key), d));
            } else out.add(new Cand(List.of(key), null));
        } catch (Throwable ignored) {}
    }

    /** /data/app/<random>/<package>/lib/arm64/libffmpeg.so of an installed FFmpeg plugin app (the folder may not be listable: then nothing is found). */
    private static void androidScan(List<Cand> out, Set<String> seen) {
        try {
            File[] l1 = new File("/data/app").listFiles();
            if (l1 == null) return;
            for (File a : l1) {
                File[] l2 = a.listFiles();
                if (l2 == null) continue;
                for (File b : l2) {
                    if (!b.getName().toLowerCase(Locale.ROOT).contains("ffmpeg")) continue;
                    for (String arch : new String[]{"arm64", "arm64-v8a"}) {
                        addFile(out, seen, b.toPath().resolve("lib").resolve(arch).resolve("libffmpeg.so"));
                        addFile(out, seen, b.toPath().resolve("lib").resolve(arch).resolve("ffmpeg"));
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void extract(Path dir) throws IOException {
        Files.createDirectories(dir);
        for (String f : FILES) {
            Path out = dir.resolve(f);
            try (InputStream in = FFmpegBin.class.getClassLoader().getResourceAsStream(RES + f)) {
                if (in == null) throw new FileNotFoundException("missing in the ffmpeg add-on: " + RES + f);
                byte[] data = in.readAllBytes();
                if (!Files.exists(out) || Files.size(out) != data.length) {
                    Path tmp = dir.resolve(f + ".part");
                    Files.write(tmp, data);
                    Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            File fo = out.toFile();
            fo.setReadable(true, false); fo.setExecutable(true, false);
        }
    }

    /** Starts "<cmd> -version" and (if it works) "-encoders". */
    private static boolean probe(List<String> cmd, String ld) {
        try {
            String v = run(cmd, ld, "-version");
            log.append(String.join(" ", cmd)).append(" -> ").append(v.lines().findFirst().orElse("(no output)")).append('\n');
            if (!v.toLowerCase(Locale.ROOT).contains("ffmpeg version")) {
                if (error.isEmpty()) error = v.lines().findFirst().orElse("ffmpeg gave no output");
                return false;
            }
            String enc = run(cmd, ld, "-hide_banner", "-encoders");
            x264 = enc.contains("libx264");
            log.append("libx264: ").append(x264).append(", mpeg4: ").append(enc.contains(" mpeg4 ")).append('\n');
            return true;
        } catch (Throwable t) {
            log.append(String.join(" ", cmd)).append(" failed: ").append(t).append('\n');
            if (error.isEmpty()) error = t.toString();
            return false;
        }
    }

    private static String run(List<String> cmd, String ld, String... args) throws Exception {
        List<String> c = new ArrayList<>(cmd); c.addAll(Arrays.asList(args));
        ProcessBuilder pb = new ProcessBuilder(c).redirectErrorStream(true);
        applyEnv(pb, ld);
        Process p = pb.start();
        p.getOutputStream().close();
        byte[] out = p.getInputStream().readAllBytes();
        if (!p.waitFor(20, TimeUnit.SECONDS)) { p.destroyForcibly(); throw new IOException("timeout"); }
        return new String(out);
    }

    /** Environment for the ffmpeg process (also used by ReplayExport). */
    public static void applyEnv(ProcessBuilder pb, String ld) {
        if (ld != null) {
            // only our folder: the launcher's own LD_LIBRARY_PATH / LD_PRELOAD would load its libraries into ffmpeg
            pb.environment().put("LD_LIBRARY_PATH", ld);
            pb.environment().remove("LD_PRELOAD");
        }
    }
}
