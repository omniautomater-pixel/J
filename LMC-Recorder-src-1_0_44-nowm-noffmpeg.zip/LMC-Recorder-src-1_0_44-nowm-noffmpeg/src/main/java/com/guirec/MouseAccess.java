package com.guirec;
/** Implemented by MouseHandlerMixin so the replay can move/click/scroll the mouse. */
public interface MouseAccess {
    void guirec$set(double x, double y);
    void guirec$button(long window, int button, int mods, int action);
    void guirec$move(long window, double x, double y);
    void guirec$scroll(long window, double dx, double dy);
}
