package com.guirec;

/**
 * v1.0.34: packet timeline de-jitter. When the game (or the server) hitches while recording, the packets of several server ticks
 * arrive in ONE burst after a silent gap. Replayed as recorded, every character stands still for the gap and then jumps to where it
 * is now. Here such a burst is spread evenly over the silent gap (packets only move EARLIER, never later, order is kept), so the
 * characters walk on at an even pace from where they stopped to where they are after the hitch.
 *
 * Only a real "steady stream -> silence -> burst" is touched: the join burst (first seconds), quiet worlds, and bursts that are no
 * bigger than what normally arrives are left alone.
 */
public final class PktSmooth {
    private static final int MIN_GAP_MS = 90;         // silence shorter than this is not a hitch
    private static final int MAX_GAP_MS = 20000;      // longer = loading / paused recording
    private static final int SKIP_FIRST_MS = 3000;    // the join burst
    private static final int BURST_STEP_MS = 10;      // packets closer than this belong to the burst
    private PktSmooth() {}

    /** Same, without packet contents: the burst is spread evenly by packet count. */
    public static int smooth(int[] ms) { return smooth(ms, null); }

    /** key of a packet = (packet id, first number after it). Entity packets (move / rotate / teleport / motion...) start with the entity id,
     *  so the same key coming again inside a burst = the next server tick has started. */
    private static long key(byte[] d) {
        if (d == null || d.length == 0) return -1;
        int p = 0;
        long id = 0; int sh = 0;
        while (p < d.length && sh < 35) { int b = d[p++] & 0xFF; id |= (long) (b & 0x7F) << sh; sh += 7; if ((b & 0x80) == 0) break; }
        long x = 0; sh = 0;
        while (p < d.length && sh < 35) { int b = d[p++] & 0xFF; x |= (long) (b & 0x7F) << sh; sh += 7; if ((b & 0x80) == 0) break; }
        return id * 1_000_003L + x;
    }

    /** ms[] = packet times (non-decreasing), data[] = the packets (may be null). Rewrites ms in place; returns how many packets were moved. */
    public static int smooth(int[] ms, byte[][] data) {
        int n = ms.length, moved = 0, i = 1;
        while (i < n) {
            int gap = ms[i] - ms[i - 1];
            int a = i - 1;
            if (gap < MIN_GAP_MS || gap > MAX_GAP_MS || ms[a] < SKIP_FIRST_MS) { i++; continue; }
            int cnt = 0;                                                      // packets in the 600 ms before the silence = the normal rate
            for (int j = a; j >= 0 && ms[a] - ms[j] <= 600; j--) cnt++;
            if (cnt < 10) { i++; continue; }                                  // no steady stream before: a quiet world, not a hitch
            int b = i;                                                        // end of the burst after the silence
            while (b + 1 < n && ms[b + 1] - ms[b] <= BURST_STEP_MS && b - i < 20000) b++;
            int c = b - i + 1;
            double expected = cnt * (gap / 600.0);                            // what should have arrived during the silence
            if (c < 6 || c < 0.5 * expected) { i = b + 1; continue; }         // too small to be the caught-up ticks
            int t0 = ms[a], span = ms[i] - ms[a];                             // (read before the loop: it rewrites ms[i])
            // split the burst into its server ticks: a packet key that repeats starts the next tick
            int[] grp = null; int groups = 0; double step = 0;
            if (data != null) {
                grp = new int[c];
                long ticks0 = Math.max(1, Math.round(span / 50.0));
                java.util.HashMap<Long, Integer> freq = new java.util.HashMap<>();
                long[] ks = new long[c];
                for (int k = 0; k < c; k++) { ks[k] = key(data[i + k]); if (ks[k] >= 0) freq.merge(ks[k], 1, Integer::sum); }
                java.util.HashSet<Long> seen = new java.util.HashSet<>();
                for (int k = 0; k < c; k++) {
                    Integer f = ks[k] >= 0 ? freq.get(ks[k]) : null;
                    boolean tickKey = f != null && f >= Math.max(3, ticks0 / 2);      // seen in about every tick: an entity that moves all the time
                    if (tickKey && !seen.add(ks[k])) { groups++; seen.clear(); seen.add(ks[k]); }
                    grp[k] = groups;
                }
                groups++;
                long ticks = Math.max(1, Math.round(span / 50.0));
                if (groups < 2 || groups < ticks - 1) grp = null;             // fewer groups than ticks missed: not whole ticks, spread by count instead
                else step = span / (double) ticks;                            // tick g is delivered g+1 steps after the last packet before the silence
            }
            for (int k = 0; k < c; k++) {
                int t = grp != null ? t0 + (int) Math.round((grp[k] + 1) * step) : t0 + (int) ((long) (k + 1) * span / c);
                if (t < ms[i + k]) { ms[i + k] = t; moved++; }
            }
            i = b + 1;
        }
        return moved;
    }
}
