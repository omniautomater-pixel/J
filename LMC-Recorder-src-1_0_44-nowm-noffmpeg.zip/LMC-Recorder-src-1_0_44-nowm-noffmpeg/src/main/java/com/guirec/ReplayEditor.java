package com.guirec;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * State of the replay editor (what is deleted / split / marked) + the timeline drawing shared by the editor screen and the HUD bar.
 * Nothing is written until Save: the original replay is never touched, Save creates NEW files in the Replays list.
 * All times are in ms on the ORIGINAL timeline of the replay.
 */
public final class ReplayEditor {
    private ReplayEditor() {}

    public static volatile boolean active;        // a replay is playing in edit mode
    public static volatile boolean wantEditor;    // the editor screen should be open (it comes back after seeks / server menus)
    public static Path source;
    public static int total;
    public static int markA = -1, markB = -1;
    public static volatile String msg = "";
    public static volatile boolean saving;
    /** {0, from, to} = deleted part, {1, at, 0} = split point, in the order the user did it (for Undo). */
    public static final List<int[]> ops = new ArrayList<>();

    public static void begin(Path src, int totalMs) {
        source = src; total = Math.max(1, totalMs); ops.clear(); markA = -1; markB = -1; msg = ""; saving = false;
        active = true; wantEditor = true;
    }

    public static void end() { active = false; wantEditor = false; ops.clear(); markA = -1; markB = -1; }

    public static void addDelete(int a, int b) {
        int lo = Math.max(0, Math.min(a, b)), hi = Math.min(total, Math.max(a, b));
        if (hi - lo < 100) { msg = "Part is too short (mark A and B first)"; return; }
        ops.add(new int[]{0, lo, hi});
        markA = -1; markB = -1;
        msg = "Deleted " + fmt(lo) + " - " + fmt(hi);
    }

    public static void addSplit(int t) {
        if (t < 200 || t > total - 200) { msg = "Cannot split this close to the start / end"; return; }
        ops.add(new int[]{1, t, 0});
        msg = "Split at " + fmt(t);
    }

    public static void undo() {
        if (ops.isEmpty()) { msg = "Nothing to undo"; return; }
        int[] o = ops.remove(ops.size() - 1);
        msg = o[0] == 0 ? "Undid delete " + fmt(o[1]) + " - " + fmt(o[2]) : "Undid split at " + fmt(o[1]);
    }

    public static List<int[]> deleted() {
        List<int[]> l = new ArrayList<>();
        for (int[] o : ops) if (o[0] == 0) l.add(new int[]{o[1], o[2]});
        return l;
    }

    public static List<Integer> splits() {
        List<Integer> l = new ArrayList<>();
        for (int[] o : ops) if (o[0] == 1) l.add(o[1]);
        return l;
    }

    /** If ms is inside a deleted part, the end of that part (the replay jumps there), else -1. */
    public static int deletedEnd(int ms) {
        int best = -1;
        for (int[] o : ops) if (o[0] == 0 && ms >= o[1] && ms < o[2]) best = Math.max(best, o[2]);
        return best;
    }

    public static String fmt(int ms) {
        int t = Math.max(0, ms) / 100;
        return String.format("%d:%02d.%d", t / 600, (t / 10) % 60, t % 10);
    }

    /** Save the edit into the Replays list on a background thread (the file can be big). */
    public static void saveAsync(Minecraft mc) {
        if (saving) return;
        if (ops.isEmpty()) { msg = "Nothing changed yet: Delete or Split first"; return; }
        saving = true;
        msg = "Saving...";
        final Path src = source;
        final List<int[]> del = deleted();
        final List<Integer> sp = splits();
        final int tot = total;
        final Path dir = mc.gameDirectory.toPath().resolve("guirec").resolve("replays");
        Thread t = new Thread(() -> {
            try {
                List<Path> files = ReplayEdit.save(src, del, sp, tot, dir);
                StringBuilder sb = new StringBuilder("Saved " + files.size() + " replay" + (files.size() > 1 ? "s" : "") + " to the Replays list");
                msg = sb.toString();
            } catch (Throwable e) {
                e.printStackTrace();
                msg = "Save failed: " + e;
            } finally { saving = false; }
        }, "guirec-save");
        t.setDaemon(true);
        t.start();
    }

    // ---------------------------------------------------------------- drawing
    private static int px(int ms, int x, int w) { return x + (int) ((long) w * Math.max(0, Math.min(total, ms)) / total); }

    /** Timeline: grey bar, red = deleted, green = A..B selection, yellow = split, white = playhead. */
    public static void drawBar(GuiGraphicsExtractor g, int x, int y, int w, int h, int curMs) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF3A3A3A);
        for (int[] o : ops) {
            if (o[0] != 0) continue;
            g.fill(px(o[1], x, w), y, Math.max(px(o[1], x, w) + 1, px(o[2], x, w)), y + h, 0xFFB03030);
        }
        if (markA >= 0 && markB >= 0) {
            int a = px(Math.min(markA, markB), x, w), b = px(Math.max(markA, markB), x, w);
            g.fill(a, y, Math.max(a + 1, b), y + h, 0x9055E055);
        }
        if (markA >= 0) g.fill(px(markA, x, w), y - 3, px(markA, x, w) + 2, y + h + 3, 0xFF55FF55);
        if (markB >= 0) g.fill(px(markB, x, w), y - 3, px(markB, x, w) + 2, y + h + 3, 0xFF55FF55);
        for (int[] o : ops) if (o[0] == 1) g.fill(px(o[1], x, w), y - 4, px(o[1], x, w) + 2, y + h + 4, 0xFFFFDD55);
        int c = px(curMs, x, w);
        g.fill(c - 1, y - 4, c + 2, y + h + 4, 0xFFFFFFFF);
    }

    /** Thin bar + time at the bottom of the screen while the replay plays in edit mode (the editor screen draws its own). */
    public static void drawHud(GuiGraphicsExtractor g) {
        var mc = Minecraft.getInstance();
        if (!active || !ReplayPlayer.isPlaying() || mc.gui.screen() instanceof ReplayEditorScreen) return;
        int w = g.guiWidth(), h = g.guiHeight();
        drawBar(g, 6, h - 7, w - 12, 3, ReplayPlayer.timeMs());
        g.text(mc.font, "EDIT  " + fmt(ReplayPlayer.timeMs()) + " / " + fmt(total) + "   F8 = editor", 6, h - 19, 0xFFFFFFFF);
    }
}
