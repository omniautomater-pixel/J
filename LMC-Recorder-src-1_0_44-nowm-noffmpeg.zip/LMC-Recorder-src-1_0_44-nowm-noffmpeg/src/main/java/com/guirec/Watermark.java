package com.guirec;

/**
 * "LMC Recorder" watermark in the bottom-right corner of every exported frame, white at 30 % opacity (with a soft dark shadow so it
 * can be read on bright pictures too). Drawn straight into the raw RGBA frame with a built-in 5x7 pixel font (no fonts / AWT needed,
 * works on phones). Text size follows the frame height, so it looks the same at 720p and at 4K.
 */
public final class Watermark {
    public static final String TEXT = "LMC Recorder";
    public static boolean enabled = false;
    private static final float ALPHA = 0.30f;

    // 5 columns x 7 rows, one string per row ('#' = pixel)
    private static final String[][] FONT = {
        /* L */ {"#....", "#....", "#....", "#....", "#....", "#....", "#####"},
        /* M */ {"#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"},
        /* C */ {".####", "#....", "#....", "#....", "#....", "#....", ".####"},
        /* R */ {"####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"},
        /* e */ {".....", ".....", ".###.", "#...#", "#####", "#....", ".####"},
        /* c */ {".....", ".....", ".####", "#....", "#....", "#....", ".####"},
        /* o */ {".....", ".....", ".###.", "#...#", "#...#", "#...#", ".###."},
        /* r */ {".....", ".....", "#.##.", "##..#", "#....", "#....", "#...."},
        /* d */ {"....#", "....#", ".####", "#...#", "#...#", "#...#", ".####"},
    };
    private static int glyph(char c) {
        switch (c) {
            case 'L': return 0; case 'M': return 1; case 'C': return 2; case 'R': return 3;
            case 'e': return 4; case 'c': return 5; case 'o': return 6; case 'r': return 7; case 'd': return 8;
            default: return -1;   // space
        }
    }

    private Watermark() {}

    /** rgba = w*h*4 bytes (top row first). */
    public static void draw(byte[] rgba, int w, int h) {
        if (!enabled) return;
        int s = Math.max(1, Math.round(h / 270f));          // pixel size: 4 at 1080p, 8 at 4K
        int adv = 6 * s;                                    // 5 columns + 1 gap
        int tw = TEXT.length() * adv - s, th = 7 * s;
        int margin = Math.max(6, h / 45);
        int x0 = w - margin - tw, y0 = h - margin - th;
        if (x0 < 0 || y0 < 0) return;
        for (int i = 0; i < TEXT.length(); i++) {
            int g = glyph(TEXT.charAt(i));
            if (g < 0) continue;
            for (int ry = 0; ry < 7; ry++) for (int cx = 0; cx < 5; cx++) {
                if (FONT[g][ry].charAt(cx) != '#') continue;
                int px = x0 + i * adv + cx * s, py = y0 + ry * s;
                block(rgba, w, h, px + Math.max(1, s / 3), py + Math.max(1, s / 3), s, 0, 0, 0);   // shadow
            }
        }
        for (int i = 0; i < TEXT.length(); i++) {
            int g = glyph(TEXT.charAt(i));
            if (g < 0) continue;
            for (int ry = 0; ry < 7; ry++) for (int cx = 0; cx < 5; cx++) {
                if (FONT[g][ry].charAt(cx) != '#') continue;
                block(rgba, w, h, x0 + i * adv + cx * s, y0 + ry * s, s, 255, 255, 255);
            }
        }
    }

    private static void block(byte[] p, int w, int h, int x, int y, int s, int r, int g, int b) {
        for (int yy = y; yy < y + s && yy < h; yy++) for (int xx = x; xx < x + s && xx < w; xx++) {
            int o = (yy * w + xx) * 4;
            p[o]     = (byte) Math.round((p[o] & 255) * (1 - ALPHA) + r * ALPHA);
            p[o + 1] = (byte) Math.round((p[o + 1] & 255) * (1 - ALPHA) + g * ALPHA);
            p[o + 2] = (byte) Math.round((p[o + 2] & 255) * (1 - ALPHA) + b * ALPHA);
        }
    }
}
