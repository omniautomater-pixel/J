package com.guirec.mixin;

import com.guirec.CustomSkins;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom skin / cape switch for YOUR player only (the local player, also inside a replay). */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
    @Inject(method = "getSkin()Lnet/minecraft/world/entity/player/PlayerSkin;", at = @At("RETURN"), cancellable = true)
    private void guirec$skin(CallbackInfoReturnable<PlayerSkin> cir) {
        if (Minecraft.getInstance().player != (Object) this) return;
        PlayerSkin s = CustomSkins.apply(cir.getReturnValue());
        if (s != cir.getReturnValue()) cir.setReturnValue(s);
    }
}
