package com.guirec.mixin;

import com.guirec.FarChunks;
import net.minecraft.server.level.ChunkMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/** Vanilla clamps the server view distance to 2..32; allow up to 64 (far record). */
@Mixin(ChunkMap.class)
public class ChunkMapMixin {
    @ModifyConstant(method = "setServerViewDistance", constant = @Constant(intValue = 32), require = 0)
    private int guirec$maxServerView(int vanilla) { return FarChunks.MAX_CHUNKS; }
}
