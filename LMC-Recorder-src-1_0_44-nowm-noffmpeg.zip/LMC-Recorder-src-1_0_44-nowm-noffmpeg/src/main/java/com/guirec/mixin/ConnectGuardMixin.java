package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.TransferState;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** v1.0.35: while the recorded MENUS play, the recorded click on "Join Server" must not open a REAL connection. */
@Mixin(ConnectScreen.class)
public abstract class ConnectGuardMixin {
    @Inject(method = "startConnecting(Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/client/Minecraft;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;Lnet/minecraft/client/multiplayer/ServerData;ZLnet/minecraft/client/multiplayer/TransferState;)V",
            at = @At("HEAD"), cancellable = true)
    private static void guirec$noRealJoin(Screen parent, Minecraft mc, ServerAddress address, ServerData data, boolean quickPlay, TransferState transfer, CallbackInfo ci) {
        if (ReplayPlayer.blockRealJoin()) ci.cancel();
    }
}
