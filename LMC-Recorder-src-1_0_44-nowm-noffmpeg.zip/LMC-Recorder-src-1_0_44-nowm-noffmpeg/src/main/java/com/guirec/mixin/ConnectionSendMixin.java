package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import io.netty.channel.ChannelFutureListener;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** During a replay there is no server: drop everything the client tries to send. */
@Mixin(Connection.class)
public class ConnectionSendMixin {
    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
            at = @At("HEAD"), cancellable = true)
    private void guirec$dropOutgoing(Packet<?> packet, ChannelFutureListener listener, boolean flush, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying()) ci.cancel();
    }
}
