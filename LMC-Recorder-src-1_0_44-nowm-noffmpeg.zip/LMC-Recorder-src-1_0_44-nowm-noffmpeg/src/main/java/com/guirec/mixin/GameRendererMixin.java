package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "render()V", at = @At("TAIL"))
    private void guirec$frame(CallbackInfo ci) {
        ReplayRecorder.onFrame(Minecraft.getInstance());
        com.guirec.ReplayExport.afterFrame(Minecraft.getInstance());
    }

    /**
     * THE camera fix. In 26.1 a frame is: renderFrame -> GameRenderer.update (Camera.update: camera position + rotation are
     * taken from the player HERE) -> pick -> extract -> render. The replay used to move the player at the start of render(),
     * i.e. AFTER the camera had already been built, so the camera always showed the PREVIOUS frame's override (and on tick
     * frames the replay's own physics position): constant jitter, worse the faster you move (sprint).
     * The replay now sets camera / player state right before Camera.update.
     */
    @Inject(method = "update(Lnet/minecraft/client/DeltaTracker;)V", at = @At("HEAD"), require = 0)
    private void guirec$beforeCamera(DeltaTracker tracker, CallbackInfo ci) {
        ReplayPlayer.onFrame(Minecraft.getInstance(), 0f);
        ReplayPlayer.cameraHookRan = true;
    }

    /** Fallback: if for some frame update() did not run, do it here (late, but better than nothing). */
    @Inject(method = "render()V", at = @At("HEAD"))
    private void guirec$beforeFrame(CallbackInfo ci) {
        if (!ReplayPlayer.cameraHookRan) ReplayPlayer.onFrame(Minecraft.getInstance(), 0f);
        ReplayPlayer.cameraHookRan = false;
    }

    /** View bobbing comes from the replay's own physics (walkDist / bob), not from the recording: it is the random shake while sprinting. */
    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true, require = 0)
    private void guirec$noBob(net.minecraft.client.renderer.state.level.CameraRenderState state, com.mojang.blaze3d.vertex.PoseStack pose, CallbackInfo ci) {
        if (com.guirec.ReplayPlayer.suppressBob()) ci.cancel();
    }
}
