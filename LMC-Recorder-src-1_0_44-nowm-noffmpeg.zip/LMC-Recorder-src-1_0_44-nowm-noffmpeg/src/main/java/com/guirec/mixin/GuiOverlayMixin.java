package com.guirec.mixin;

import com.guirec.ReplayEditor;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Thin timeline bar at the bottom while a replay plays in edit mode (the editor screen draws its own bigger one). */
@Mixin(Hud.class)
public class GuiOverlayMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/DeltaTracker;)V", at = @At("TAIL"), require = 0)
    private void guirec$editBar(GuiGraphicsExtractor g, DeltaTracker tracker, CallbackInfo ci) {
        if (ReplayEditor.active) ReplayEditor.drawHud(g);
    }
}
