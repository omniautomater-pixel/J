package com.guirec.mixin;

import com.mojang.blaze3d.platform.InputConstants;
import com.guirec.KbAccess;
import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Records every key the player presses (recording) and replays them (replay). The REAL game logic then does the rest. */
@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin implements KbAccess {
    @Shadow public abstract void keyPress(long window, int action, KeyEvent event);
    @Shadow public abstract void charTyped(long window, CharacterEvent event);

    @Override public void guirec$key(long w, int action, int key, int sc, int mods) { keyPress(w, action, new KeyEvent(key, sc, mods)); }
    @Override public void guirec$char(long w, int cp) { charTyped(w, new CharacterEvent(cp)); }

    @Inject(method = "keyPress(JILnet/minecraft/client/input/KeyEvent;)V", at = @At("HEAD"), cancellable = true)
    private void guirec$onKey(long window, int action, KeyEvent e, CallbackInfo ci) {
        if (!ReplayPlayer.injecting) ReplayPlayer.lastWindow = window;
        if (!ReplayPlayer.injecting && action == InputConstants.PRESS && e.key() == InputConstants.KEY_F8) ReplayPlayer.userF8 = true;   // YOUR F8 (not the recorded one)
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injecting) {
            if (!ReplayPlayer.realInput() && e.key() != InputConstants.KEY_F7 && e.key() != InputConstants.KEY_F8) ci.cancel();   // F7/F8 stay usable; the editor screen gets the real keys
            return;
        }
        ReplayRecorder.inputKey(action, e.key(), e.keycode(), e.modifiers());
    }

    @Inject(method = "charTyped(JLnet/minecraft/client/input/CharacterEvent;)V", at = @At("HEAD"), cancellable = true)
    private void guirec$onChar(long window, CharacterEvent e, CallbackInfo ci) {
        if (ReplayPlayer.isPlaying() && !ReplayPlayer.injecting) { if (!ReplayPlayer.realInput()) ci.cancel(); return; }
        ReplayRecorder.inputChar(e.codepoint());
    }
}
