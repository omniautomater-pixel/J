package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import com.guirec.ReplayRecorder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The partial tick the game renders a frame with is computed at the START of runTick. The recorder used to stamp the
 * camera with the time at the END of the frame, so every sample was late by a random amount (the frame's render time).
 * While sprinting that random error is multiplied by a high speed = visible shake. Remember the frame start instead.
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "runTick(Z)V", at = @At("HEAD"))
    private void guirec$frameStart(boolean advance, CallbackInfo ci) {
        ReplayRecorder.frameStart();
    }

    /** Leaving the game in ANY way ends the replay state (not only F7). */
    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;ZZ)V", at = @At("HEAD"), require = 0)
    private void guirec$leave3(Screen screen, boolean keepResourcePacks, boolean showMessage, CallbackInfo ci) {
        ReplayPlayer.onLeave();
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;Z)V", at = @At("HEAD"), require = 0)
    private void guirec$leave2(Screen screen, boolean keepResourcePacks, CallbackInfo ci) {
        ReplayPlayer.onLeave();
    }
}
