package com.guirec.mixin;

import com.guirec.RecorderScreen;
import com.guirec.SkinScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Title screen buttons (F8 does not work in menus): Replays and Skins. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void guirec$button(CallbackInfo ci) {
        this.addRenderableWidget(Button.builder(Component.literal("Watch out"),
                b -> this.minecraft.gui.setScreen(new RecorderScreen(this)))
                .bounds(this.width - 90, 6, 84, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Skins"),
                b -> this.minecraft.gui.setScreen(new SkinScreen(this))).bounds(this.width - 90, 28, 84, 20).build());
        this.addRenderableWidget(com.guirec.RecButton.make(6, 6, 110));   // v1.0.38: "Start rec full" top left: records from the title screen on, up to leaving the world
    }
}
