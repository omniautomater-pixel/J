package com.guirec.mixin;

import com.guirec.ReplayPlayer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.WorldOpenFlows;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.levelgen.WorldOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** v1.0.35: while the recorded MENUS play, "Play Selected World" / "Create New World" must not really open or create a world. */
@Mixin(WorldOpenFlows.class)
public abstract class WorldOpenGuardMixin {
    @Inject(method = "openWorld(Ljava/lang/String;Ljava/lang/Runnable;)V", at = @At("HEAD"), cancellable = true)
    private void guirec$noRealOpen(String name, Runnable onFail, CallbackInfo ci) {
        if (ReplayPlayer.blockRealJoin()) ci.cancel();
    }

    @Inject(method = "createFreshLevel(Ljava/lang/String;Lnet/minecraft/world/level/LevelSettings;Lnet/minecraft/world/level/levelgen/WorldOptions;Ljava/util/function/Function;Lnet/minecraft/client/gui/screens/Screen;)V",
            at = @At("HEAD"), cancellable = true)
    private void guirec$noRealCreate(String name, LevelSettings settings, WorldOptions options, java.util.function.Function<?, ?> dims, Screen parent, CallbackInfo ci) {
        if (ReplayPlayer.blockRealJoin()) ci.cancel();
    }
}
